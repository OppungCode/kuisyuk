class AnswerOption {
  AnswerOption({this.id, this.title});

  final String? id;
  final String? title;
}
