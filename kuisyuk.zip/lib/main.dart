import 'package:flutter/material.dart';
import 'package:flutterquiz/app/app.dart';

void main() async => runApp(await initializeApp());
