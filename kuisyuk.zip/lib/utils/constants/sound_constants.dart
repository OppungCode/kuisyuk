const correctAnswerSoundTrack = 'assets/sounds/right.mp3';
const wrongAnswerSoundTrack = 'assets/sounds/wrong.mp3';
const clickEventSoundTrack = 'assets/sounds/click.mp3';
